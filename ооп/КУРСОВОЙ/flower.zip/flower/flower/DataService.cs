﻿using System;
using System.Collections.Generic;
using flower.Models;
using System.IO;
using System.Text.Json;

public static class DataService
{
    public static string ProductsFile = "products.json";
    public static string UsersFile = "users.json";

    private static JsonSerializerOptions options = new JsonSerializerOptions()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public static List<Product> LoadProducts()
    {
        if (!File.Exists(ProductsFile))
            return new List<Product>();

        var json = File.ReadAllText(ProductsFile);
        return JsonSerializer.Deserialize<List<Product>>(json, options);
    }

    public static void SaveProducts(List<Product> products)
    {
        var json = JsonSerializer.Serialize(products, options);
        File.WriteAllText(ProductsFile, json);
    }

    public static List<User> LoadUsers()
    {
        if (!File.Exists(UsersFile))
            return new List<User>();

        var json = File.ReadAllText(UsersFile);
        return JsonSerializer.Deserialize<List<User>>(json, options);
    }

    public static void SaveUsers(List<User> users)
    {
        var json = JsonSerializer.Serialize(users, options);
        File.WriteAllText(UsersFile, json);
    }
}

