﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace flower.Models
{
    public enum UserRole
    {
        Client,
        Administrator
    }

    public class User
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        public string Username { get; set; }
        public string PasswordHash { get; set; }  // Позже - хранить хэши, сейчас просто строки для примера
        public string FullName { get; set; }
        public string Email { get; set; }
        public UserRole Role { get; set; } = UserRole.Client;
    }
}
