﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace flower.Models
{
    public class Product
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        // Названия и описание
        public string ShortName { get; set; }
        public string FullName { get; set; }
        public string Description { get; set; }

        // Изображения (пути или URI)
        public List<string> ImagePaths { get; set; } = new List<string>();

        // Категория
        public string Category { get; set; }

        // Рейтинг от 0 до 5 (например)
        public double Rating { get; set; }

        // Цена
        public decimal Price { get; set; }

        // Количество на складе
        public int StockQuantity { get; set; }

        // Дополнительные параметры
        public string Color { get; set; }
        public string Size { get; set; }
        public string CountryOfOrigin { get; set; }
        public decimal DiscountPercent { get; set; } // 0..100%
        public bool IsAvailable => StockQuantity > 0;
        public List<Guid> RelatedProductIds { get; set; } = new List<Guid>();

        // Количество купленных
        public int TimesPurchased { get; set; }

        // Производитель
        public string Manufacturer { get; set; }
    }

}
